import re
with open('/root/aegis10/c2_comms/c2_client.c', 'r') as f:
    data = f.read()

new_recv = '''static ssize_t tls_recv(tls_conn_t *conn, void *buf, size_t cap) {
  if (!conn || !conn->connected)
    return -1;
  int ret = SSL_read(conn->ssl, buf, (int)cap);
  if (ret <= 0) {
      int err = SSL_get_error(conn->ssl, ret);
      if (err == SSL_ERROR_ZERO_RETURN || (err == SSL_ERROR_SYSCALL && errno == 0)) {
          return 0; // Treat dirty EOF as clean EOF to prevent data drops
      }
      return -1;
  }
  return (ssize_t)ret;
}'''

data = re.sub(r'static ssize_t tls_recv\(tls_conn_t \*conn, void \*buf, size_t cap\) \{\s*if \(\!conn \|\| \!conn->connected\)\s*return -1;\s*return \(ssize_t\)SSL_read\(conn->ssl, buf, \(int\)cap\);\s*\}', new_recv, data)

with open('/root/aegis10/c2_comms/c2_client.c', 'w') as f:
    f.write(data)
