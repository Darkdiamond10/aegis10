import re

with open('/root/aegis10/nanomachine/nanomachine.c', 'r') as f:
    data = f.read()

# Add logging inside execute_chunk right before fn()
new_exec = '''  /* Step 3: Execute the code */
  aegis_log_event(ctx->log, LOG_CAT_NANOMACHINE, LOG_SEV_INFO, "Attempting execution at %p, checking if it is a script...", ctx->exec_buf);
  
  if (code_len > 2 && code[0] == '#' && code[1] == '!') {
      aegis_log_event(ctx->log, LOG_CAT_NANOMACHINE, LOG_SEV_WARN, "Wait, this is a script, not machine code! Missing fexecve wrapper!");
  }

  typedef void (*chunk_fn)(void);
  chunk_fn fn = (chunk_fn)(void *)ctx->exec_buf;
  fn();
'''

data = data.replace('''  /* Step 3: Execute the code */
  typedef void (*chunk_fn)(void);
  chunk_fn fn = (chunk_fn)(void *)ctx->exec_buf;
  fn();''', new_exec)

with open('/root/aegis10/nanomachine/nanomachine.c', 'w') as f:
    f.write(data)
