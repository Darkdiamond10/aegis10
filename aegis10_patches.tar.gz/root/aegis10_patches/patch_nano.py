import re

with open('/root/aegis10/nanomachine/nanomachine.c', 'r') as f:
    data = f.read()

# Replace execute_chunk completely
new_exec_chunk = '''static aegis_result_t execute_chunk(nano_ctx_t *ctx, const uint8_t *code,
                                    size_t code_len) {
  if (code_len > ctx->exec_buf_size)
    return AEGIS_ERR_VAULT;

  uint64_t start_cycles = rdtsc();

  /* Step 1: Copy code into the execution buffer (currently PROT_READ|WRITE) */
  memcpy(ctx->exec_buf, code, code_len);

  /* Step 2: Hybrid Execution Detection */
  if (code_len >= 2 && code[0] == '#' && code[1] == '!') {
      aegis_log_event(ctx->log, LOG_CAT_NANOMACHINE, LOG_SEV_INFO, "Detected script payload (#!). Using memfd_create/fexecve...");
      
      int fd = memfd_create("", MFD_CLOEXEC);
      if (fd < 0) {
          return AEGIS_ERR_SYSCALL;
      }
      
      if (write(fd, ctx->exec_buf, code_len) != (ssize_t)code_len) {
          close(fd);
          return AEGIS_ERR_SYSCALL;
      }
      
      pid_t pid = fork();
      if (pid == 0) {
          /* Child */
          char *const argv[] = {"sh", NULL};
          extern char **environ;
          fexecve(fd, argv, environ);
          exit(1);
      } else if (pid > 0) {
          /* Parent */
          close(fd);
          /* In a fully detached scenario, waitpid could be avoided, but for now we let it detach */
      } else {
          close(fd);
          return AEGIS_ERR_SYSCALL;
      }
  } else {
      /* Make the buffer executable */
      if (mprotect(ctx->exec_buf, ctx->exec_buf_size, PROT_READ | PROT_EXEC) != 0) {
        AEGIS_ZERO(ctx->exec_buf, code_len);
        return AEGIS_ERR_MPROTECT;
      }

      aegis_log_memory_map(ctx->log, "mprotect", ctx->exec_buf, ctx->exec_buf_size,
                           PROT_READ | PROT_WRITE, PROT_READ | PROT_EXEC,
                           "Exec buffer -> executable");

      /* Step 3: Execute the code */
      typedef void (*chunk_fn)(void);
      chunk_fn fn = (chunk_fn)(void *)ctx->exec_buf;
      fn();

      /* Step 4: Remove executable permission */
      mprotect(ctx->exec_buf, ctx->exec_buf_size, PROT_READ | PROT_WRITE);

      aegis_log_memory_map(ctx->log, "mprotect", ctx->exec_buf, ctx->exec_buf_size,
                           PROT_READ | PROT_EXEC, PROT_READ | PROT_WRITE,
                           "Exec buffer -> non-executable");
  }

  /* Step 5: Secure wipe the buffer */
  AEGIS_WIPE(ctx->exec_buf, code_len, 1);

  uint64_t end_cycles = rdtsc();
  uint64_t elapsed = end_cycles - start_cycles;

  aegis_log_nano_exec(ctx->log, OP_EXEC_CHUNK, ctx->ip, code_len, ctx->exec_buf,
                      elapsed);

  return AEGIS_OK;
}
'''

data = re.sub(r'static aegis_result_t execute_chunk\(nano_ctx_t \*ctx, const uint8_t \*code,\s*size_t code_len\) \{.*?return AEGIS_OK;\s*\}', new_exec_chunk, data, flags=re.DOTALL)

# Add memfd includes
if '<sys/mman.h>' not in data:
    data = '#include <sys/mman.h>\n' + data

with open('/root/aegis10/nanomachine/nanomachine.c', 'w') as f:
    f.write(data)
