with open('/root/aegis10/c2_server/server.py', 'r') as f:
    data = f.read()

# Instead of try/except block just suppressing BrokenPipeError, maybe wait for flush?
# Wait, the problem is HTTP/1.0 200 OK because the server uses BaseHTTPRequestHandler without a protocol_version.
# So by default it sends HTTP/1.0, and curl closes connection after the headers because there's no Content-Length for the payload initially. Wait, my patch added Content-Length!
pass
