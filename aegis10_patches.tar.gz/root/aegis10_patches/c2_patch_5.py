with open('/root/aegis10/c2_server/server.py', 'r') as f:
    data = f.read()

# I already modified do_POST to send Content-Length earlier, but maybe not in all paths. 
# Wait, curl reported 'OpenSSL SSL_read: error:0A000126:SSL routines::unexpected eof while reading' 
pass
