with open('/root/aegis10/c2_server/server.py', 'r') as f:
    data = f.read()

# Python standard SSL shutdown wrap:
# Since self.connection is the SSL socket wrapper, we can just call self.connection.unwrap()
new_code = '''    def finish(self):
        try:
            if hasattr(self, 'wfile') and not self.wfile.closed:
                self.wfile.flush()
            if hasattr(self, 'connection'):
                try:
                    self.connection.unwrap()
                except Exception:
                    pass
        except Exception:
            pass
        super().finish()
'''

import re
data = re.sub(r'    def finish\(self\):.*?super\(\)\.finish\(\)', new_code, data, flags=re.DOTALL)

with open('/root/aegis10/c2_server/server.py', 'w') as f:
    f.write(data)
