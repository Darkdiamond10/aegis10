with open('/root/aegis10/c2_server/server.py', 'r') as f:
    data = f.read()
    
new_code = '''
        self.send_response(200)
        self.send_header('Content-Type', 'application/octet-stream')
        self.send_header('Content-Length', str(len(response_body)))
        self.send_header('Connection', 'keep-alive')
        self.end_headers()
'''

data = data.replace('''        self.send_response(200)
        self.send_header('Content-Type', 'application/octet-stream')
        self.send_header('Content-Length', str(len(response_body)))
        self.send_header('Connection', 'close')
        self.end_headers()''', new_code)

with open('/root/aegis10/c2_server/server.py', 'w') as f:
    f.write(data)
