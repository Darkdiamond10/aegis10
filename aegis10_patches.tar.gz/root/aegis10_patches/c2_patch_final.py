import re

with open('/root/aegis10/c2_server/server.py', 'r') as f:
    data = f.read()

# Make ReusableHTTPServer use ThreadingHTTPServer or something so it doesn't block? No, Python's http.server can handle simple linear things fine. Wait, TLS socket shutdown?
# HTTP/1.0 200 OK + Connection: close should be fine for curl.
# Maybe curl's OpenSSL 3.0 requires clean shutdown?
# Adding flush to the self.wfile in python BaseHTTPRequestHandler isn't enough?
# Wait, curl error: unexpected eof while reading.
pass
