with open('/root/aegis10/c2_server/server.py', 'r') as f:
    data = f.read()

# Add flush and proper exception handling
new_code = '''
        try:
            self.wfile.write(response_body)
            self.wfile.flush()
        except ssl.SSLEOFError:
'''

data = data.replace('''        try:
            self.wfile.write(response_body)
        except ssl.SSLEOFError:''', new_code)

with open('/root/aegis10/c2_server/server.py', 'w') as f:
    f.write(data)
