with open('/root/aegis10/c2_server/server.py', 'r') as f:
    data = f.read()

# For AegisC2Handler, ensure it inherits from SimpleHTTPRequestHandler or that it sets protocol_version
new_code = '''class AegisC2Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    
    def log_message(self, format, *args):
'''

data = data.replace('''class AegisC2Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, format, *args):''', new_code)

with open('/root/aegis10/c2_server/server.py', 'w') as f:
    f.write(data)
